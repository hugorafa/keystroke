import numpy as np
from sklearn.svm import OneClassSVM
import joblib
import os

MODEL_PATH = "model.joblib"

class KeystrokeModel:

    def __init__(self):
        self.model = OneClassSVM(kernel="rbf", gamma="auto")

    def train(self, X):
        self.model.fit(X)
        joblib.dump(self.model, MODEL_PATH)

    def load(self):
        if os.path.exists(MODEL_PATH):
            self.model = joblib.load(MODEL_PATH)

    def predict(self, X):
        return self.model.predict(X)
