import numpy as np

def extract_features(keystrokes):
    dwell_times = []
    flight_times = []

    for i in range(len(keystrokes)):
        dwell = keystrokes[i]["up"] - keystrokes[i]["down"]
        dwell_times.append(dwell)

        if i > 0:
            flight = keystrokes[i]["down"] - keystrokes[i-1]["up"]
            flight_times.append(flight)

    return np.array(dwell_times + flight_times)
