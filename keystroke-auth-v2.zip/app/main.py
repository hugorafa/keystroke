from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import numpy as np
from model import KeystrokeModel
from utils import extract_features

app = FastAPI()

app.mount("/static", StaticFiles(directory="frontend"), name="static")

@app.get("/")
def read_root():
    return FileResponse("frontend/index.html")

model = KeystrokeModel()
model.load()

training_data = []

class KeystrokeInput(BaseModel):
    keystrokes: list

@app.post("/train")
def train(data: KeystrokeInput):
    features = extract_features(data.keystrokes)
    training_data.append(features)

    if len(training_data) >= 5:
        X = np.array(training_data)
        model.train(X)
        return {"status": "Modelo treinado"}

    return {"status": f"Amostras coletadas: {len(training_data)}"}

@app.post("/verify")
def verify(data: KeystrokeInput):
    features = extract_features(data.keystrokes)
    prediction = model.predict([features])

    if prediction[0] == 1:
        return {"result": "Usuário legítimo"}
    else:
        return {"result": "Intruso detectado"}
